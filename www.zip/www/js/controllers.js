angular.module('app.controllers', [])
  
.controller('splashCtrl', function($scope) {

})
   
.controller('loginCtrl', function($scope, $http, $ionicPopup, $state) {
    $scope.data = {};
 
    $scope.login = function() {
        $http.post("http://simerjit.crystalbiltech.com/xamarine/index.php?route=feed/rest_api/login",{email: $scope.data.email,
            password:$scope.data.password})
       .success(function(response){
            console.log(response);
            if(response.status == true){
                alert(response.response);
                $state.go('menu.home');
            }else{
                alert(response.response);
                $state.go('login');
            }
            }).error(function(response){
                alert("Unable to login");
      });
}
})
   
.controller('signUpCtrl', function($scope,$http,$state) {
    $scope.data = {};
$scope.register=function(){
   $http.post("http://simerjit.crystalbiltech.com/xamarine/index.php?route=feed/rest_api/register", $scope.data)
        .success(function(response){
            console.log(response);
            if(response.status == true){
                alert(response.response);
                $state.go('menu.home');
            }else{
                alert(response.response);
                $state.go('menu.signUp');
            }
            }).error(function(response){
                alert("Unable to signup");
      });
  }
})
  
  .controller('logoutCtrl', function($scope,$state){
       $scope.data = {};
      $scope.logout=function(){
          alert("Successfully Logout ");
      $state.go('login');
           
      
}
})
.controller('homeCtrl', function($scope) {

})
   
.controller('addACategoryCtrl', function($scope) {

})
   
.controller('selectCategoryCtrl', function($scope) {

})
.controller('selectGradeCtrl', function($scope) {

})
.controller('qaCtrl', function($scope) {

})

.controller('vocabularyCtrl', function($scope) {

})
   
.controller('mathCtrl', function($scope) {

})
   
.controller('benjaminFranklinCtrl', function($scope) {

})
   
.controller('selectAuthorCtrl', function($scope) {

})
   
.controller('radioCtrl', function($scope) {

})
   
.controller('ebookCtrl', function($scope) {

})
   
.controller('teachAlertsCtrl', function($scope) {

})
   
.controller('contactUsCtrl', function($scope) {

})
   
.controller('aboutUsCtrl', function($scope) {

})
   
.controller('albertEinsteinCtrl', function($scope) {

})
.controller('profileCtrl', function($scope) {

})
.controller('editProfileCtrl', function($scope) {

})

    
	


