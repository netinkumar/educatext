angular.module('app.routes', [])

.config(function($stateProvider, $urlRouterProvider) {

  // Ionic uses AngularUI Router which uses the concept of states
  // Learn more here: https://github.com/angular-ui/ui-router
  // Set up the various states which the app can be in.
  // Each state's controller can be found in controllers.js
  $stateProvider
    
  .state('login', {
    url: '/page2',
        templateUrl: 'templates/login.html',
        controller: 'loginCtrl'
  })

  .state('menu.signUp', {
    url: '/page3',
    views: {
      'side-menu21': {
        templateUrl: 'templates/signUp.html',
        controller: 'signUpCtrl'
      }
    }
  })

  .state('menu.home', {
    url: '/page4',
    views: {
      'side-menu21': {
        templateUrl: 'templates/home.html',
        controller: 'homeCtrl'
      }
    }
  })

  .state('addACategory', {
    url: '/page5',
    templateUrl: 'templates/addACategory.html',
    controller: 'addACategoryCtrl'
  })

  .state('menu.selectCategory', {
    url: '/selectCategory',
    views: {
      'side-menu21': {
        templateUrl: 'templates/selectCategory.html',
        controller: 'selectCategoryCtrl'
      }
    }
  })
  .state('menu.selectGrade', {
    url: '/selectGrade',
    views: {
      'side-menu21': {
        templateUrl: 'templates/selectGrade.html',
        controller: 'selectGradeCtrl'
      }
    }
  })
  .state('menu.qa', {
    url: '/qa',
    views: {
      'side-menu21': {
        templateUrl: 'templates/qa.html',
        controller: 'qaCtrl'
      }
    }
  })

  .state('vocabulary', {
    url: '/page8',
    templateUrl: 'templates/vocabulary.html',
    controller: 'vocabularyCtrl'
  })

  .state('math', {
    url: '/page17',
    templateUrl: 'templates/math.html',
    controller: 'mathCtrl'
  })

  .state('benjaminFranklin', {
    url: '/page9',
    templateUrl: 'templates/benjaminFranklin.html',
    controller: 'benjaminFranklinCtrl'
  })

  .state('menu.selectAuthor', {
    url: '/selectAuthor',
    views: {
      'side-menu21': {
        templateUrl: 'templates/selectAuthor.html',
        controller: 'selectAuthorCtrl'
      }
    }
  })

  .state('radio', {
    url: '/page10',
    templateUrl: 'templates/radio.html',
    controller: 'radioCtrl'
  })

  .state('ebook', {
    url: '/page12',
    templateUrl: 'templates/ebook.html',
    controller: 'ebookCtrl'
  })

  .state('teachAlerts', {
    url: '/page13',
    templateUrl: 'templates/teachAlerts.html',
    controller: 'teachAlertsCtrl'
  })

  .state('contactUs', {
    url: '/page14',
    templateUrl: 'templates/contactUs.html',
    controller: 'contactUsCtrl'
  })

  .state('aboutUs', {
    url: '/page15',
    templateUrl: 'templates/aboutUs.html',
    controller: 'aboutUsCtrl'
  })

  .state('albertEinstein', {
    url: '/page16',
    templateUrl: 'templates/albertEinstein.html',
    controller: 'albertEinsteinCtrl'
  })
  
  .state('menu.profile', {
    url: '/profile',
    views: {
      'side-menu21': {
        templateUrl: 'templates/profile.html',
        controller: 'profileCtrl'
      }
    }
  })
  .state('menu.editProfile', {
    url: '/editProfile',
    views: {
      'side-menu21': {
        templateUrl: 'templates/editProfile.html',
        controller: 'editProfileCtrl'
      }
    }
  })

  .state('menu', {
    url: '/side-menu21',
    templateUrl: 'templates/menu.html',
    abstract:true
  })

$urlRouterProvider.otherwise('/page2')

  

});